﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class dataScript {
 
    //time and tries 
    public static float time
    {
        get;
        
        set;
         
    }
    public static float tries
    {
        get;

        set;

    }
}
